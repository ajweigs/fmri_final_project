function [ output_args ] = createSPMJobFile_realign( dirName, copy_file,temp_file, subName)

origdir = pwd;
cd(dirName)

% read in the master jobfile for the given preprocessing step
% read out a new temporary jobfile that will rewrite the master jobfile to
% replace subject indices with the appropriate subject name
fid_in = fopen(copy_file);
fid_out = fopen(temp_file,'w');

count = 1;

while 1
    % create tline variable that reads each line in the file
    tLine = fgetl(fid_in);
    if ~ischar(tLine), break, end
    disp(tLine)
    
    % remove whitespace from the string
    lineCheck = strtrim(tLine);
    
    % if the current line is a character string and begins with ', replace the
    % given indices in the line with the appropriate subject name
    if ischar(lineCheck) && strcmp(lineCheck(1), '''')
        tLine(49:54) = subName;
        tLine(61:66) = subName;
    end
    
    % rewrite the temp file
    fprintf(fid_out,'%s\n',tLine);

    count = count+1;
end
fclose(fid_in);
fclose(fid_out);
 
fclose all;


cd(origdir)
end

