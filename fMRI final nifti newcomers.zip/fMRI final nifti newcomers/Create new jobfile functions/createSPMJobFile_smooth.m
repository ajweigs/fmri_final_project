function [ output_args ] = createSPMJobFile_smooth( dirName, copy_file_smooth,temp_file_smooth, subName)

origdir = pwd;
cd(dirName)

% read in the master jobfile for smoothing
% read out a new temporary jobfile that will rewrite the master jobfile to
% replace subject indices with the appropriate subject name
fid_in = fopen(copy_file_smooth);
fid_out = fopen(temp_file_smooth,'w');

count = 1;

while 1
    % create tline variable that reads each line in the file
    tLine = fgets(fid_in);
    if ~ischar(tLine), break, end
    disp(tLine)
    
    % remove whitespace from the string
    lineCheck = strtrim(tLine);
    
    % if the current line contains the string 'func'...
    % isscalar used to convert strfind to a logical vector; if string is
    % found strfind returns scalar value, if not it returns empty array
    if  isscalar(strfind(lineCheck, 'func'))
        % if that line also contains the word 'mean', replace certain 
        % indices with appropriate subject name
        if  isscalar(strfind(lineCheck, 'mean'))
            tLine(49:54) = subName;
            tLine(66:71) = subName;
        % else replace other indices
        else
            tLine(49:54) = subName;
            tLine(62:67) = subName;
        end
    end
    
    % rewrite the temp file
    fprintf(fid_out,'%s\n',tLine);
    count = count+1;
    
end
fclose(fid_in);
fclose(fid_out);
 
fclose all;


cd(origdir)
end

