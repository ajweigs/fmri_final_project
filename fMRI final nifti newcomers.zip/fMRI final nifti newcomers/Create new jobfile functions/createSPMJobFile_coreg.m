function [ output_args ] = createSPMJobFile_coreg( dirName, copy_file_coreg,temp_file_coreg, subName)

origdir = pwd;
cd(dirName)

% read in the master jobfile for coregistration
% read out a new temporary jobfile that will rewrite the master jobfile to
% replace subject indices with the appropriate subject name
fid_in = fopen(copy_file_coreg);
fid_out = fopen(temp_file_coreg,'w');

count = 1;

while 1
    % create tline variable that reads each line in the file
    tLine = fgets(fid_in);
    if ~ischar(tLine), break, end
    disp(tLine)
    
    % remove whitespace from the string
    lineCheck = strtrim(tLine);
    
    % if the current line contains the string 'Users'...
    % isscalar used to convert strfind to a logical vector; if string is
    % found strfind returns scalar value, if not it returns empty array
    if  isscalar(strfind(lineCheck, 'Users'))
        % if the given indices in the string match the word func, then
        % replace certain indices with appropriate subject name
        if strcmp(lineCheck(56:59), 'func')
        tLine(49:54) = subName;
        tLine(65:70) = subName;
        % elseif the given indices in the string match the word anat, then
        % replace other indices with appropriate subject name
        % need separate loops because subject names are not at the same
        % location within these file names
        elseif strcmp(lineCheck(56:59), 'anat')
        tLine(49:54) = subName;
        tLine(61:66) = subName;
        end
    end
    
    % rewrite the temp file   
    fprintf(fid_out,'%s\n',tLine);
    count = count+1;
    
end
fclose(fid_in);
fclose(fid_out);
 
fclose all;


cd(origdir)
end

