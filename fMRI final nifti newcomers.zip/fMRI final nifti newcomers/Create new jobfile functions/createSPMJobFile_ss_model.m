function [ output_args ] = createSPMJobFile_ss_model( dirName, copy_file_ss_model,temp_file_ss_model, subName)

origdir = pwd;
cd(dirName)

% read in the master jobfile for single subject model specification
% read out a new temporary jobfile that will rewrite the master jobfile to
% replace subject indices with the appropriate subject name
fid_in = fopen(copy_file_ss_model);
fid_out = fopen(temp_file_ss_model,'w');

count = 1;

while 1
    % create tline variable that reads each line in the file
    tLine = fgets(fid_in);
    if ~ischar(tLine), break, end
    disp(tLine)
    
    % remove whitespace from the string
    lineCheck = strtrim(tLine);
    
    % if the current line contains the string 'alex'...
    % isscalar used to convert strfind to a logical vector; if string is
    % found strfind returns scalar value, if not it returns empty array
    if  isscalar(strfind(lineCheck, 'alex'))
        % if that line also contains the word 'Stats'
        if strcmp(lineCheck(49:53), 'Stats')
            tLine(55:60) = subName;
        % elseif that line contains the string 'sw'
        elseif isscalar(strfind(lineCheck, 'sw'))
            tLine(49:54) = subName;
            tLine(63:68) = subName;
        % elseif that line contains the string 'rp'
        elseif isscalar(strfind(lineCheck, 'rp'))
            tLine(49:54) = subName;
            tLine(64:69) = subName;
        end
    end 
    

    % rewrite the temp file
    fprintf(fid_out,'%s\n',tLine);
    count = count+1;
    
end
fclose(fid_in);
fclose(fid_out);
 
fclose all;


cd(origdir)
end

