%-----------------------------------------------------------------------
% Job saved on 26-Apr-2017 23:38:37 by cfg_util (rev $Rev: 6460 $)
% spm SPM - SPM12 (6906)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.stats.fmri_est.spmmat = {
'/Users/alexweigand/Desktop/MATLAB/ds157_R1.0.1/Stats/sub-01/SPM.mat'
};
matlabbatch{1}.spm.stats.fmri_est.write_residuals = 0;
matlabbatch{1}.spm.stats.fmri_est.method.Classical = 1;
