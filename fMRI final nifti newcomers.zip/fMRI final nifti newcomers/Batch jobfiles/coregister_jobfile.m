matlabbatch{1}.spm.spatial.coreg.estwrite.ref = {
'/Users/alexweigand/Desktop/MATLAB/ds157_R1.0.1/sub-01/func/meansub-01_task-passiveimageviewing_bold.nii,1'
};
matlabbatch{1}.spm.spatial.coreg.estwrite.source = {
'/Users/alexweigand/Desktop/MATLAB/ds157_R1.0.1/sub-01/anat/sub-01_T1w.nii,1'
};
matlabbatch{1}.spm.spatial.coreg.estwrite.other = {''};
matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.cost_fun = 'nmi';
matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.sep = [4 2];
matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.tol = [0.02 0.02 0.02 0.001 0.001 0.001 0.01 0.01 0.01 0.001 0.001 0.001];
matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.fwhm = [7 7];

