function [] = norm_func(dirName)

basedir = dirName;
%read text file that contains number of frames for each subject
numframes = textread([basedir '/' 'numframesList.txt'],'%u');

% create variable for all of the subject indices that will need to be
% replaced in the batch jobfiles
allSubs = {'sub-01',	'sub-02',	'sub-03',	'sub-04',	'sub-05',	'sub-06',	'sub-07',	'sub-08',	'sub-09',	'sub-10',	'sub-11',	'sub-12',	'sub-13',	'sub-14',	'sub-15',	'sub-16',	'sub-17',	'sub-18',	'sub-19',	'sub-20',	'sub-21',	'sub-22',	'sub-23',	'sub-24',	'sub-25',	'sub-26',	'sub-27',	'sub-28',	'sub-29',	'sub-30',};

for i=1:length(allSubs)
    subName = allSubs{i};
    dirName = [basedir '/' subName '/func'];
    
    % select job file based on number of frames for given subject
    if numframes(i)==375
        copy_file_norm = 'norm_jobfile_1.m';
    elseif numframes(i)==370
        copy_file_norm = 'norm_jobfile_2.m';
    end
    
    % create a new job file that will be rewritten for each subject to call
    % the correct batch files for that subject
    % see the createSPMJobFile function for more info
    temp_file_norm = ['new_norm_jobfile_' subName '.m'];
    % call function that will create new jobfile for given subject
    createSPMJobFile_norm(dirName,copy_file_norm,temp_file_norm, subName);


    % List of open inputs
    % output of save batch and script
    % enter the number of runs here
    nrun = 1;
    % assign newly created temp_file with replaced subject indices to the
    % variable jobfile
    jobfile = [dirName '/' temp_file_norm];
    inputs = cell(0, nrun);

    % call jobfile, let jobman do its thing
    spm('defaults', 'FMRI');
    spm_jobman('run', jobfile, inputs{:});
end
