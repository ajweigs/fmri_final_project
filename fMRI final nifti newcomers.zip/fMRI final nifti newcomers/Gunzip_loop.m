baseDir = '/Users/alexweigand/Desktop/MATLAB/ds157_R1.0.1/';
numSubjects = 30;

for subjInd=1:numSubjects
    imagePathAnat = sprintf('sub-%02i/anat/', subjInd);
    FileNameAnat = fullfile(baseDir, imagePathAnat);
    %navigate to FileNameAnat
    cd(FileNameAnat);
    gunzip('*.gz');
    
    imagePathFunc = sprintf('sub-%02i/func/', subjInd);
    FileNameFunc = fullfile(baseDir, imagePathFunc);
    %navigate to FileNameFunc
    cd(FileNameFunc);
    gunzip('*.gz');
    
end
