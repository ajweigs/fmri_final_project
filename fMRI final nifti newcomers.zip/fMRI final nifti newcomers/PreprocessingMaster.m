%%MasterFile for preprocessing steps!

%%Begin by entering the directory Name: 

dirName= '/Users/alexweigand/Desktop/MATLAB/ds157_R1.0.1';

%% Realignment

realign_func(dirName);

%% Coregistration 

coreg_func(dirName);

%% Segmentation

segment_func(dirName);

%% Normalization

norm_func(dirName);

%% Smoothing 

smooth_func(dirName);

